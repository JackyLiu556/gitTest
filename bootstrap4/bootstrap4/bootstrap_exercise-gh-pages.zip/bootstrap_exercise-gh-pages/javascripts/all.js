'use strict';

var helpers = {
  getQuery: function getQuery() {
    console.log('getQuery');
    return 'getQuery';
  }
};
console.log('return ' + helpers.getQuery());
console.log('return ' + helpers.getQuery() + ' line 2');
// ES6 範例程式碼
//# sourceMappingURL=all.js.map
